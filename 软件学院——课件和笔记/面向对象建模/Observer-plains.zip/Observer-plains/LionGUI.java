import java.awt.*;
import javax.swing.*;

public class LionGUI extends JFrame implements Observer
{
    private JPanel showPanel;
    private JLabel stateLabel;
    private JTextArea actionText;
    private String grassState="";
    private PlainGUI plainGuiObj;

    public LionGUI(PlainGUI objPlainGUI) throws Exception
    {
       super("Lion GUI- Observer 5");
       plainGuiObj = objPlainGUI;

       // Create controls
       showPanel = new JPanel();
       actionText = new JTextArea(4, 20);
       actionText.setFont(new Font("Serif", Font.PLAIN, 14));
       actionText.setLineWrap(true);
       actionText.setWrapStyleWord(true);

       //Create Labels
       stateLabel = new JLabel("Grass state");

       //For layout purposes, put the buttons in a separate panel
       JPanel buttonPanel = new JPanel();
       buttonPanel.add(stateLabel);
       buttonPanel.add(actionText);

       JPanel imgPanel=new ImagePanel("Lion.jpg");

       Container contentPane = getContentPane();
       contentPane.add(buttonPanel, BorderLayout.CENTER);
       contentPane.add(imgPanel, BorderLayout.EAST);

       setSize(400, 150);
       setVisible(true);
       plainGuiObj.register(this);
     }

     public void takeAction(Observable subject)
     {
        if (subject == plainGuiObj)
        {
            //get subject's state
           grassState = plainGuiObj.getGrassState().trim();
           stateLabel.setText("Grass state - " + grassState);

           if (grassState.compareTo("Green")== 0 )
	       {
	  	       actionText.setBackground(Color.green);
	  	       enter();
			   huntBuffalo();
			   huntAntelope();
	  	       breed();
	       }
	       else if (grassState.compareTo("Yellow")== 0 )
	       {
	  	       actionText.setBackground(Color.yellow);
	  	       leave();
	       }
        }
     }

     public void huntBuffalo() {
	    actionText.append("Lions are hunting for buffalos.");
	 }
	 public void huntAntelope() {
	    actionText.append("Lions  are hunting for antelopes.");
	 }
	 public void breed() {
	    actionText.append("Lions  are enter breeding period.");
	 }
	 public void enter() {
	    actionText.append("Lions  are entering the plain.");
	 }
	 public void leave() {
	    actionText.setText("Now all the vegetarian animals are leaving, "+
	                       " we also must follow them to greener and warmer plains.");
	 }

}// end of class

