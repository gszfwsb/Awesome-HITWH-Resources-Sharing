
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class TestObserverUI extends JFrame implements ItemListener
{
  private JButton submitBtn;
  private JButton exitBtn;
  private JPanel checkBoxPanel;
  private JPanel btnPanel;
  private JPanel choicePanel;
  private int[] states;
  private JCheckBox AntelopeGUI, BuffaloGUI, HareGUI,TigerGUI,LionGUI, FoxGUI;
  public final int SELECTED = ItemEvent.SELECTED;
  public final int DESELECTED = ItemEvent.DESELECTED;

  public TestObserverUI()
  {
    super("Visitor Pattern Example with JCheckbox");
    states = new int[20];
    setUpChoicePanel();
    setUpScrollPanes();
   }

  private void setUpChoicePanel()
  {
      submitBtn = new JButton("Submit");
      submitBtn.addActionListener( new ButtonActionListener());
      exitBtn = new JButton("Exit");
      exitBtn.addActionListener( new ButtonActionListener());

      JPanel btnPanel =new JPanel();
      btnPanel.add(submitBtn);
      btnPanel.add(exitBtn);

      //Create the check boxes.
      AntelopeGUI  = new JCheckBox("AntelopeGUI");
      BuffaloGUI  = new JCheckBox("BuffaloGUI");
      HareGUI  = new JCheckBox("HareGUI");
	  TigerGUI  = new JCheckBox("TigerGUI");
      LionGUI  = new JCheckBox("LionGUI");
      FoxGUI  = new JCheckBox("FoxGUI");

      AntelopeGUI.setMnemonic(KeyEvent.VK_C);
      BuffaloGUI.setMnemonic(KeyEvent.VK_C);
      HareGUI.setMnemonic(KeyEvent.VK_C);
      TigerGUI.setMnemonic(KeyEvent.VK_C);
      LionGUI.setMnemonic(KeyEvent.VK_C);
	  FoxGUI.setMnemonic(KeyEvent.VK_C);

      //Register a listener for the check boxes.
      AntelopeGUI.addItemListener(this);
      BuffaloGUI.addItemListener(this);
      HareGUI.addItemListener(this);
      TigerGUI.addItemListener(this);
      LionGUI.addItemListener(this);
	  FoxGUI.addItemListener(this);

      //Set up the picture label
      checkBoxPanel = new JPanel();
      checkBoxPanel.setBackground(Color.pink);
      checkBoxPanel.setLayout(new GridLayout(3,2));

      checkBoxPanel.add(AntelopeGUI);
      checkBoxPanel.add(BuffaloGUI);
      checkBoxPanel.add(HareGUI);
      checkBoxPanel.add(TigerGUI);
      checkBoxPanel.add(LionGUI);
      checkBoxPanel.add(FoxGUI);

      choicePanel = new JPanel();
      choicePanel.setMinimumSize(new Dimension(300, 150));
      choicePanel.setLayout(new BorderLayout());

      JLabel label = new JLabel("Select listeners");
      label.setFont(new Font("Arial",  Font.BOLD ,24));
      label.setMinimumSize(new Dimension(300, 100));
      //label.setForeground(Color.blue);

      choicePanel.add(label, "North");
      choicePanel.add(checkBoxPanel, "Center");
      choicePanel.add(btnPanel, "South");
  }

   // All the scroll panes are set up
   private void setUpScrollPanes()
   {
       getContentPane().add(choicePanel);
  	   setSize(new Dimension(300, 200));
       setVisible(true);
    }

  //===================
  // Button Listener
  //===================
  class ButtonActionListener implements ActionListener
  {
    public void actionPerformed(ActionEvent e) {
		 try{
		         createObjects(e); // throws ;
		    }
		    catch (Exception ect)
           {}
    }
  }

   public void itemStateChanged(ItemEvent e)
   {

        Object source = e.getItemSelectable();
	    int state = e.getStateChange();

	    if (source == AntelopeGUI) {
			states[0]=state;
        }
        else if (source == BuffaloGUI) {
            states[1]=state;
        }
        else if (source == HareGUI) {
		    states[2]=state;
        }
        else if (source == TigerGUI) {
			states[3]=state;
        }
        else if (source == LionGUI) {
			states[4] = state;
        }
        else if (source == FoxGUI) {
			states[5]=state;
		}
    }

  private void createObjects(ActionEvent e) throws Exception
  {
	  int len = 6;
	  PlainGUI objSubject = new PlainGUI();

      if (e.getActionCommand().equals("Submit"))
  	  {
		 for(int m = 0; m < len; m++ )
		 {
            if ((m==0) && (states[0] == SELECTED)) {
  	           new AntelopeGUI(objSubject);
  	        }
  	        else if ((m==1) && (states[1] == SELECTED)) {
  		       new BuffaloGUI(objSubject);
  	        }
  	        else if ((m==2) && (states[2] == SELECTED)) {
  	   	       new HareGUI(objSubject);
  	        }
  	        else if  ((m==3) && (states[3] == SELECTED)) {
                new TigerGUI(objSubject);
  	        }
  	        else if ((m==4) && (states[4] == SELECTED))  {
  		        new LionGUI(objSubject);
  	        }
  	        else if ((m==5) && (states[5] == SELECTED)) {
               new FoxGUI(objSubject);
  	        }
         }  //end for loop
	  }
      else if (e.getActionCommand().equals("Exit")) {
  		        System.exit(1);
  	  }
    }

  //--------------------------------------------------------------
  public static void main(String args[])
  {
    try
    {
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
    }
    catch (Exception evt) {}

    TestObserverUI frame = new TestObserverUI();
    frame.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        System.exit(0);
      }
    });
    frame.setSize(300, 200);
    frame.setVisible(true);
  }
}

