
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import com.sun.java.swing.plaf.windows.*;

public class PlainGUI extends JFrame implements Observable
{
   public static final String SUBMIT = "Submit";
   public static final String EXIT = "Exit";

   private JPanel buttonPanel;
   private JComboBox grassStateList;
   private JButton btnOK, btnExit;
   private Vector observersList;
   private String grassState;

   public PlainGUI() throws Exception {
      super("PlainGUI - Observable");

      observersList = new Vector();

      // Create controls
      grassStateList = new JComboBox();
      btnOK = new JButton(PlainGUI.SUBMIT);
      btnOK.setMnemonic(KeyEvent.VK_S);
      btnExit = new JButton(PlainGUI.EXIT);
      btnExit.setMnemonic(KeyEvent.VK_X);

      //Create Labels
      JLabel lblDepartmentList = new JLabel("Select grass state:");

      ButtonHandler vf = new ButtonHandler(this);

      btnOK.addActionListener(vf);
      btnExit.addActionListener(vf);

      buttonPanel = new JPanel();
      //----------------------------------------------
      GridBagLayout gridbag = new GridBagLayout();
      buttonPanel.setLayout(gridbag);
      GridBagConstraints gbc = new GridBagConstraints();
      buttonPanel.add(lblDepartmentList);
      buttonPanel.add(grassStateList);
      buttonPanel.add(btnOK);
      buttonPanel.add(btnExit);

      gbc.insets.top = 5;
      gbc.insets.bottom = 5;
      gbc.insets.left = 5;
      gbc.insets.right = 5;

      gbc.gridx = 0;
      gbc.gridy = 0;
      gridbag.setConstraints(lblDepartmentList, gbc);
      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 0;
      gridbag.setConstraints(grassStateList, gbc);

      gbc.anchor = GridBagConstraints.EAST;
      gbc.insets.left = 2;
      gbc.insets.right = 2;
      gbc.insets.top = 40;
      gbc.gridx = 0;
      gbc.gridy = 6;
      gridbag.setConstraints(btnOK, gbc);
      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 1;
      gbc.gridy = 6;
      gridbag.setConstraints(btnExit, gbc);

      Container contentPane = getContentPane();
      contentPane.add(buttonPanel, BorderLayout.CENTER);
      try {
        UIManager.setLookAndFeel(new WindowsLookAndFeel());
        SwingUtilities.updateComponentTreeUI(
        PlainGUI.this);
      } catch (Exception ex) {
         System.out.println(ex);
        }

      initialize();
      setSize(300, 200);
      setVisible(true);
   }
   private void initialize() throws Exception {
     // fill some test data here into the listbox.
      grassStateList.addItem("Green");
      grassStateList.addItem("Yellow");
   }
   public void register(Observer obs) {
      // Add to the list of Observers
      observersList.addElement(obs);
   }
   public void unRegister(Observer obs) {
      // remove from the list of Observers
   }
   public void notifyObservers() {
      // Send notify to all Observers
      for (int i = 0; i < observersList.size(); i++) {
         Observer observer = (Observer) observersList.elementAt(i);
         observer.takeAction(this);
      }
   }
   public String getGrassState() {
      return grassState;
   }
   public void setGrassState(String st) {
      grassState = st;
   }

   //***************************//
   class ButtonHandler implements ActionListener
   {
      PlainGUI subject;

      public ButtonHandler() {  }
	  public ButtonHandler(PlainGUI plain)
	  {
	      subject = plain;
      }

      public void actionPerformed(ActionEvent e)
      {
         if (e.getActionCommand().equals(PlainGUI.EXIT)) {
            System.exit(1);
         }
         if (e.getActionCommand().equals(PlainGUI.SUBMIT)) {
            String state = (String)grassStateList.getSelectedItem();

        if (state.compareTo("Green")== 0 )
            buttonPanel.setBackground(Color.green);
        else if (state.compareTo("Yellow")== 0 )
            buttonPanel.setBackground(Color.yellow);
        //change in state
        subject.setGrassState(state);
        subject.notifyObservers();
      }
    }
  }
}// end of class

