




public interface Observer
{
  public void takeAction(Observable subject);
}
