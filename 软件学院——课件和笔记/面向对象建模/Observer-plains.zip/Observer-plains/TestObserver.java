


public class TestObserver
{
  public static void main(String[] args) throws Exception {

    //Create the observable object
    PlainGUI objSubject = new PlainGUI();

    //Create Observers
    new HareGUI(objSubject);
    new AntelopeGUI(objSubject);
    new BuffaloGUI(objSubject);

    new FoxGUI(objSubject);
    new LionGUI(objSubject);
    new TigerGUI(objSubject);
  }
}// end of class

